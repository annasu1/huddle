import { Activity } from "../domain/models";
import imported from "../data/imported.json";
import { demoActivities } from "../data/demo";
import { normalizeMany } from "../domain/normalize";
export interface CatalogRepository {
  list(): Promise<Activity[]>;
}
export class DemoRepository implements CatalogRepository {
  async list() {
    return normalizeMany([...imported, ...demoActivities]).activities;
  }
}
export class SupabaseRepository implements CatalogRepository {
  constructor(
    private url: string,
    private key: string,
    private fetcher: typeof fetch = fetch,
  ) {}
  async list() {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);
    try {
      const res = await this.fetcher(
        `${this.url.replace(/\/$/, "")}/rest/v1/activities?select=payload&published=eq.true`,
        {
          headers: { apikey: this.key, Authorization: `Bearer ${this.key}` },
          signal: controller.signal,
        },
      );
      if (!res.ok) throw Error(`Catalog unavailable (${res.status})`);
      const data: unknown = await res.json();
      if (!Array.isArray(data)) throw Error("Invalid catalog response");
      const result = normalizeMany(data.map((r) => r.payload));
      if (result.errors.length) throw Error("Catalog contains invalid records");
      return result.activities;
    } finally {
      clearTimeout(timeout);
    }
  }
}
export async function loadCatalog(
  remote: CatalogRepository | undefined,
  cached: Activity[],
) {
  if (!remote)
    return {
      activities: await new DemoRepository().list(),
      status: imported.length
        ? "Local catalog · works offline"
        : "Demo mode · works offline",
    };
  try {
    return {
      activities: await remote.list(),
      status: "Shared catalog · refreshed",
    };
  } catch {
    return {
      activities: cached.length ? cached : await new DemoRepository().list(),
      status: cached.length
        ? "Offline · using saved catalog"
        : "Catalog unavailable · using offline demo",
    };
  }
}

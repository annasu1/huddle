import * as SQLite from "expo-sqlite";
import { emptyState, LocalState, Activity } from "../domain/models";
let dbPromise: Promise<SQLite.SQLiteDatabase> | undefined;
async function db() {
  if (!dbPromise)
    dbPromise = (async () => {
      const d = await SQLite.openDatabaseAsync("huddle.db");
      await d.execAsync(
        "PRAGMA journal_mode = WAL; CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL); PRAGMA user_version = 1;",
      );
      return d;
    })();
  return dbPromise;
}
export async function readValue<T>(key: string, fallback: T): Promise<T> {
  const row = await (
    await db()
  ).getFirstAsync<{ value: string }>("SELECT value FROM kv WHERE key = ?", key);
  if (!row) return fallback;
  try {
    return JSON.parse(row.value) as T;
  } catch {
    throw Error("Local data could not be read. Please restore from an export.");
  }
}
export async function writeValue(key: string, value: unknown) {
  await (
    await db()
  ).runAsync(
    "INSERT INTO kv(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
    key,
    JSON.stringify(value),
  );
}
export const loadState = () => readValue<LocalState>("state", emptyState());
export const saveState = (s: LocalState) => writeValue("state", s);
export const loadCache = () => readValue<Activity[]>("catalog", []);

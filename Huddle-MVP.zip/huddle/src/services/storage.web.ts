import { emptyState, LocalState, Activity } from "../domain/models";
// Web preview fallback; iOS and Android use SQLite. No private data leaves this origin.
export async function readValue<T>(key: string, fallback: T): Promise<T> {
  const raw = localStorage.getItem(`huddle:${key}`);
  return raw ? JSON.parse(raw) : fallback;
}
export async function writeValue(key: string, value: unknown) {
  localStorage.setItem(`huddle:${key}`, JSON.stringify(value));
}
export const loadState = () => readValue<LocalState>("state", emptyState());
export const saveState = (s: LocalState) => writeValue("state", s);
export const loadCache = () => readValue<Activity[]>("catalog", []);

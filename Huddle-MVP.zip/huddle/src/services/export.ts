import { Platform } from "react-native";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { LocalState } from "../domain/models";
export async function exportHistory(state: LocalState) {
  const text = JSON.stringify(
    {
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      adventures: state.adventures,
      completions: state.completions,
      feedback: state.feedback,
    },
    null,
    2,
  );
  if (Platform.OS === "web") {
    const u = URL.createObjectURL(
      new Blob([text], { type: "application/json" }),
    );
    const a = document.createElement("a");
    a.href = u;
    a.download = "huddle-history.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(u), 1000);
    return;
  }
  const file = new File(Paths.cache, "huddle-history.json");
  try {
    file.write(text);
    if (!(await Sharing.isAvailableAsync()))
      throw Error("Sharing is unavailable on this device.");
    await Sharing.shareAsync(file.uri, {
      mimeType: "application/json",
      dialogTitle: "Export private Huddle history",
    });
  } finally {
    if (file.exists) file.delete();
  }
}

import { View } from "react-native";
import { Chip, Label, s } from "./ui";
import { UserPreferences } from "../domain/models";
export function Filters({
  value,
  onChange,
}: {
  value: UserPreferences;
  onChange: (v: UserPreferences) => void;
}) {
  return (
    <View style={{ gap: 18 }}>
      {(
        [
          {
            key: "budget",
            title: "Budget · USD",
            options: [0, 15, 30, 100],
            format: (n: number) => (n === 0 ? "Free" : `Up to $${n}`),
          },
          {
            key: "distanceKm",
            title: "Distance · when coordinates are known",
            options: [2, 5, 10, 25],
            format: (n: number) => `${n} km`,
          },
          {
            key: "timeMinutes",
            title: "Time for a little adventure",
            options: [30, 60, 120, 240],
            format: (n: number) => (n < 60 ? `${n} min` : `${n / 60} hr`),
          },
        ] as const
      ).map((f) => (
        <View key={f.key}>
          <Label>{f.title}</Label>
          <View style={s.row}>
            {f.options.map((n) => (
              <Chip
                key={n}
                label={f.format(n)}
                selected={value[f.key] === n}
                onPress={() => onChange({ ...value, [f.key]: n })}
              />
            ))}
          </View>
        </View>
      ))}
    </View>
  );
}

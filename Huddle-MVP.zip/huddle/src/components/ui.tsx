import React from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ScrollView,
  TextInput,
  TextInputProps,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Svg, { Ellipse, Path, Circle } from "react-native-svg";
import { router } from "expo-router";
import { useHuddle } from "../state/AppState";
export const colors = {
  bg: "#FBF8F1",
  ink: "#253E46",
  muted: "#627474",
  blue: "#C8E7F3",
  peach: "#F8DDCA",
  line: "#E4E7DF",
  green: "#E6EEDC",
};
export function Penguin({ size = 140 }: { size?: number }) {
  return (
    <Svg
      width={size}
      height={size}
      viewBox="0 0 160 160"
      accessibilityLabel="Pip, a friendly penguin"
      accessible
    >
      <Ellipse cx="80" cy="146" rx="48" ry="7" fill="#DCE5DC" />
      <Path
        d="M44 73 Q20 93 26 112 Q40 113 52 93 M115 72 Q144 84 136 107 Q121 106 111 92"
        fill="#314D57"
      />
      <Ellipse cx="80" cy="80" rx="47" ry="61" fill="#314D57" />
      <Ellipse cx="80" cy="92" rx="36" ry="44" fill="#FFFCF5" />
      <Ellipse cx="65" cy="64" rx="17" ry="21" fill="#FFFCF5" />
      <Ellipse cx="95" cy="64" rx="17" ry="21" fill="#FFFCF5" />
      <Circle cx="65" cy="66" r="4" fill="#253E46" />
      <Circle cx="95" cy="66" r="4" fill="#253E46" />
      <Path d="M72 76 Q80 91 88 76Z" fill="#E9AD76" />
      <Ellipse cx="53" cy="79" rx="7" ry="4" fill="#F1BEAB" />
      <Ellipse cx="106" cy="79" rx="7" ry="4" fill="#F1BEAB" />
      <Path
        d="M48 137 Q60 131 73 140 L73 147 L43 147Z M88 140 Q101 132 113 139 L118 147 L88 147Z"
        fill="#E9AD76"
      />
      <Path d="M46 97 Q81 111 115 96 L111 109 Q80 122 49 110Z" fill="#A4CFDA" />
      <Path d="M98 109 L111 108 L119 128 L105 132Z" fill="#A4CFDA" />
    </Svg>
  );
}
export function Button({
  children,
  onPress,
  secondary = false,
  disabled = false,
}: {
  children: React.ReactNode;
  onPress: () => void;
  secondary?: boolean;
  disabled?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        s.button,
        secondary && s.secondary,
        { opacity: disabled ? 0.45 : pressed ? 0.7 : 1 },
      ]}
    >
      <Text style={s.buttonText}>{children}</Text>
    </Pressable>
  );
}
export function Chip({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[
        s.chip,
        selected && { backgroundColor: colors.ink, borderColor: colors.ink },
      ]}
    >
      <Text
        style={{ color: selected ? "#FFF" : colors.ink, fontWeight: "600" }}
      >
        {label}
      </Text>
    </Pressable>
  );
}
export function Title({ children }: { children: React.ReactNode }) {
  return (
    <Text accessibilityRole="header" style={s.title}>
      {children}
    </Text>
  );
}
export function Body({ children }: { children: React.ReactNode }) {
  return <Text style={s.body}>{children}</Text>;
}
export function Label({ children }: { children: React.ReactNode }) {
  return <Text style={s.label}>{children}</Text>;
}
export function Field(props: TextInputProps) {
  return (
    <TextInput
      placeholderTextColor={colors.muted}
      {...props}
      style={[s.input, props.style]}
    />
  );
}
export function Card({
  children,
  tint,
}: {
  children: React.ReactNode;
  tint?: string;
}) {
  return (
    <View style={[s.card, tint ? { backgroundColor: tint } : undefined]}>
      {children}
    </View>
  );
}
export function Page({
  children,
  tab,
  back = false,
}: {
  children: React.ReactNode;
  tab?: "Discover" | "Adventures" | "Settings";
  back?: boolean;
}) {
  const { status, error, clearError } = useHuddle();
  return (
    <SafeAreaView style={s.safe}>
      <View style={s.header}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={back ? "Go back" : "Huddle home"}
          onPress={() => (back ? router.back() : router.push("/"))}
        >
          <Text style={s.logo}>
            {back ? "‹  " : ""}huddle<Text style={{ color: "#7BAEBE" }}>●</Text>
          </Text>
        </Pressable>
        <Text style={s.eyebrow}>GO A LITTLE FURTHER</Text>
      </View>
      <ScrollView
        contentContainerStyle={s.page}
        keyboardShouldPersistTaps="handled"
      >
        {error ? (
          <Card tint={colors.peach}>
            <Body>{error}</Body>
            <Button secondary onPress={clearError}>
              Dismiss message
            </Button>
          </Card>
        ) : null}
        {children}
        <Text style={s.footnote}>{status}</Text>
      </ScrollView>
      {tab && (
        <View style={s.nav}>
          {(["Discover", "Adventures", "Settings"] as const).map((name, i) => (
            <Pressable
              key={name}
              accessibilityRole="button"
              accessibilityState={{ selected: tab === name }}
              style={s.navItem}
              onPress={() =>
                router.replace((["/", "/adventures", "/settings"] as const)[i])
              }
            >
              <Text style={{ fontSize: 20, color: colors.ink }}>
                {["✧", "♡", "⚙"][i]}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  color: tab === name ? colors.ink : colors.muted,
                  fontWeight: tab === name ? "800" : "400",
                }}
              >
                {name}
              </Text>
            </Pressable>
          ))}
        </View>
      )}
    </SafeAreaView>
  );
}
export const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: {
    width: "100%",
    maxWidth: 760,
    alignSelf: "center",
    paddingHorizontal: 24,
    paddingVertical: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  logo: {
    fontSize: 28,
    fontWeight: "900",
    letterSpacing: -1.5,
    color: colors.ink,
  },
  eyebrow: {
    fontSize: 9,
    fontWeight: "800",
    letterSpacing: 1.6,
    color: colors.muted,
  },
  page: {
    padding: 24,
    paddingTop: 10,
    gap: 18,
    width: "100%",
    maxWidth: 760,
    alignSelf: "center",
    paddingBottom: 42,
  },
  title: {
    fontSize: 36,
    lineHeight: 42,
    fontWeight: "800",
    letterSpacing: -1.2,
    color: colors.ink,
  },
  body: { fontSize: 16, lineHeight: 25, color: colors.muted },
  label: {
    fontSize: 13,
    fontWeight: "700",
    color: colors.ink,
    marginBottom: 10,
  },
  button: {
    minHeight: 54,
    backgroundColor: colors.blue,
    borderRadius: 18,
    padding: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.ink,
    textAlign: "center",
  },
  secondary: {
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: colors.line,
  },
  chip: {
    minHeight: 46,
    paddingVertical: 12,
    paddingHorizontal: 17,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 24,
    backgroundColor: "#FFFEFA",
    alignItems: "center",
    justifyContent: "center",
  },
  row: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  card: {
    backgroundColor: "#FFFEFB",
    borderRadius: 24,
    padding: 22,
    gap: 12,
    borderWidth: 1,
    borderColor: colors.line,
  },
  input: {
    minHeight: 54,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 16,
    padding: 16,
    fontSize: 16,
    color: colors.ink,
    backgroundColor: "#FFFEFB",
  },
  footnote: {
    fontSize: 12,
    color: colors.muted,
    textAlign: "center",
    lineHeight: 18,
    marginTop: 8,
  },
  nav: {
    flexDirection: "row",
    borderTopWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.bg,
    paddingVertical: 10,
  },
  navItem: { flex: 1, minHeight: 48, alignItems: "center", gap: 4 },
  subtitle: {
    fontSize: 23,
    lineHeight: 29,
    fontWeight: "700",
    color: colors.ink,
  },
  tag: {
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1,
    color: colors.muted,
    textTransform: "uppercase",
  },
});

import { View, Text } from "react-native";
import { router } from "expo-router";
import { Activity, LocalState } from "../domain/models";
import { distanceKm } from "../domain/recommend";
import { Card, Body, Button, s, colors } from "./ui";
export function priceLabel(a: Activity) {
  return a.price == null
    ? "Cost unknown"
    : a.price === 0
      ? "Free"
      : `${a.priceStatus === "estimated" ? "~" : ""}${a.currency === "USD" ? "$" : `${a.currency || "?"} `}${a.price}`;
}
export function ActivityCard({
  activity: a,
  reason,
  state,
  onReject,
}: {
  activity: Activity;
  reason?: string;
  state: LocalState;
  onReject?: () => void;
}) {
  const d = distanceKm(a, state);
  return (
    <Card>
      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <Text style={s.tag}>{a.category}</Text>
        <Text style={s.tag}>{a.challenge}</Text>
      </View>
      <Text style={s.subtitle}>{a.title}</Text>
      <Body>{a.description}</Body>
      <View style={s.row}>
        <Text style={{ color: colors.ink }}>
          {priceLabel(a)} ·{" "}
          {a.durationMinutes ? `~${a.durationMinutes} min` : "Duration unknown"}
        </Text>
      </View>
      <Body>
        {a.venue?.name || a.venue?.city || "Choose a spot near you"}
        {d != null ? ` · ${d.toFixed(1)} km` : " · Distance unknown"}
      </Body>
      <Text style={s.footnote}>
        {a.type === "event"
          ? new Date(a.startTime!).toLocaleString()
          : a.openingInfo || "Check local hours"}
        {a.timeZone ? ` (${a.timeZone})` : ""}
      </Text>
      <Body>{a.whatToExpect || "Check the source for what to expect."}</Body>
      {a.whyTry && <Body>{a.whyTry}</Body>}
      <Text style={{ fontSize: 13, color: colors.muted }}>
        {a.source.platform} ·{" "}
        {a.verification === "demo"
          ? "Sample idea, not a verified listing"
          : a.verification}{" "}
        ·{" "}
        {a.availability === "available"
          ? "Reported available; recheck before going"
          : "Availability unconfirmed"}
      </Text>
      {reason && (
        <Text style={{ color: "#4C7368", fontSize: 13 }}>✧ {reason}</Text>
      )}
      <Button
        onPress={() =>
          router.push({
            pathname: "/activity/[id]",
            params: { id: a.id, reason },
          })
        }
      >
        Try this ↗
      </Button>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          gap: 10,
        }}
      >
        <View style={{ flex: 1 }}>
          <Button
            secondary
            onPress={() =>
              router.push({
                pathname: "/activity/[id]",
                params: { id: a.id, reason },
              })
            }
          >
            View details
          </Button>
        </View>
        {onReject && (
          <View style={{ flex: 1 }}>
            <Button secondary onPress={onReject}>
              Not for me
            </Button>
          </View>
        )}
      </View>
    </Card>
  );
}

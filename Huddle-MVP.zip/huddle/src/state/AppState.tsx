import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { Activity, LocalState, emptyState } from "../domain/models";
import {
  loadState,
  saveState,
  loadCache,
  writeValue,
} from "../services/storage";
import { loadCatalog, SupabaseRepository } from "../services/catalog";
interface Context {
  state: LocalState;
  catalog: Activity[];
  status: string;
  ready: boolean;
  error: string;
  clearError: () => void;
  update: (fn: (s: LocalState) => LocalState) => Promise<void>;
}
const C = createContext<Context>(null!);
export function Provider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState(emptyState),
    [catalog, setCatalog] = useState<Activity[]>([]),
    [status, setStatus] = useState("Loading your huddle…"),
    [ready, setReady] = useState(false),
    [error, setError] = useState("");
  const current = useRef(state);
  const queue = useRef(Promise.resolve());
  useEffect(() => {
    (async () => {
      try {
        const s = await loadState();
        current.current = s;
        setState(s);
        setReady(true);
        const url = process.env.EXPO_PUBLIC_SUPABASE_URL,
          key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
        const result = await loadCatalog(
          url && key ? new SupabaseRepository(url, key) : undefined,
          await loadCache(),
        );
        setCatalog(result.activities);
        setStatus(result.status);
        if (result.status.startsWith("Shared"))
          await writeValue("catalog", result.activities);
      } catch {
        setError(
          "Could not load local storage. Restart the app or check available device space.",
        );
      }
    })();
  }, []);
  const update = (fn: (s: LocalState) => LocalState) => {
    const next = queue.current.then(async () => {
      const s = fn(current.current);
      await saveState(s);
      current.current = s;
      setState(s);
    });
    queue.current = next.catch(() =>
      setError(
        "Could not save changes. Please try again; your previous data is intact.",
      ),
    );
    return next;
  };
  return (
    <C.Provider
      value={{
        state,
        catalog,
        status,
        ready,
        error,
        clearError: () => setError(""),
        update,
      }}
    >
      {children}
    </C.Provider>
  );
}
export const useHuddle = () => useContext(C);

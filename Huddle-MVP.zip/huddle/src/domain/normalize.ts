import { Activity, Mood } from "./models";
const str = (v: unknown): string | undefined =>
  typeof v === "string" && v.trim() ? v.trim() : undefined;
const num = (v: unknown, min = 0, max = Infinity): number | undefined => {
  if (
    (typeof v !== "number" && typeof v !== "string") ||
    String(v).trim() === ""
  )
    return;
  const n = Number(v);
  return Number.isFinite(n) && n >= min && n <= max ? n : undefined;
};
const date = (v: unknown) => {
  const s = str(v);
  return s && Number.isFinite(Date.parse(s))
    ? new Date(s).toISOString()
    : undefined;
};
const url = (v: unknown) => {
  try {
    const u = new URL(String(v));
    if (!["https:", "http:"].includes(u.protocol)) return;
    u.hash = "";
    for (const k of [...u.searchParams.keys()])
      if (k.startsWith("utm_")) u.searchParams.delete(k);
    return u.toString().replace(/\/$/, "");
  } catch {
    return;
  }
};
export function normalize(raw: unknown): Activity {
  if (!raw || typeof raw !== "object") throw Error("Expected an object");
  const r = raw as Record<string, any>; // Untrusted boundary: each field is normalized below.
  const title = str(r.title),
    description = str(r.description),
    id = str(r.id),
    category = str(r.category);
  if (!title || !description || !id || !category)
    throw Error("id, title, description and category are required");
  if (!["event", "evergreen"].includes(r.type))
    throw Error("type must be event or evergreen");
  const startTime = date(r.startTime),
    endTime = date(r.endTime);
  if (
    r.type === "event" &&
    (!startTime || (r.endTime && !endTime) || (endTime && endTime < startTime))
  )
    throw Error("Event needs valid, ordered ISO timestamps");
  const v = r.venue || {},
    s = r.source || {};
  const moods = (
    Array.isArray(r.moods) ? r.moods : String(r.moods || "").split("|")
  ).filter((m: unknown) =>
    ["Surprise me", "Chill", "Social", "Active", "Creative"].includes(
      String(m),
    ),
  ) as Mood[];
  return {
    id,
    title,
    description,
    category,
    type: r.type,
    moods,
    venue: {
      name: str(v.name || r.venueName),
      city: str(v.city || r.city),
      address: str(v.address || r.address),
      latitude: num(v.latitude ?? r.latitude, -90, 90),
      longitude: num(v.longitude ?? r.longitude, -180, 180),
    },
    startTime,
    endTime,
    timeZone: str(r.timeZone),
    durationMinutes: num(r.durationMinutes, 1),
    price: num(r.price),
    currency: str(r.currency),
    priceStatus: r.priceStatus === "verified" ? "verified" : "estimated",
    source: {
      platform: ["instagram", "organizer"].includes(
        s.platform || r.sourcePlatform,
      )
        ? s.platform || r.sourcePlatform
        : "curated",
      url: url(s.url || r.sourceUrl),
      sourceId: str(s.sourceId || r.sourceId),
      publishedAt: date(s.publishedAt || r.publishedAt),
    },
    verification: ["verified", "demo"].includes(r.verification)
      ? r.verification
      : "unverified",
    lastCheckedAt: date(r.lastCheckedAt),
    imageUrl: url(r.imageUrl),
    challenge: ["Moderate", "Stretch"].includes(r.challenge)
      ? r.challenge
      : "Easy",
    availability: ["available", "unavailable", "full"].includes(r.availability)
      ? r.availability
      : "unknown",
    whatToExpect: str(r.whatToExpect),
    whyTry: str(r.whyTry),
    openingInfo: str(r.openingInfo),
    restrictions: str(r.restrictions),
  };
}
export function normalizeMany(rows: unknown[]): {
  activities: Activity[];
  errors: { row: number; message: string }[];
  duplicates: number;
} {
  const activities: Activity[] = [],
    errors: { row: number; message: string }[] = [],
    keys = new Set<string>();
  let duplicates = 0;
  rows.forEach((r, i) => {
    try {
      const a = normalize(r);
      const ks = [
        `id:${a.id}`,
        a.source.sourceId
          ? `source:${a.source.platform}:${a.source.sourceId}`
          : "",
        a.source.url ? `url:${a.source.url}` : "",
        `match:${a.title.toLowerCase()}:${a.venue?.city?.toLowerCase() || ""}:${a.startTime || ""}`,
      ].filter(Boolean);
      if (ks.some((k) => keys.has(k))) {
        duplicates++;
        return;
      }
      ks.forEach((k) => keys.add(k));
      activities.push(a);
    } catch (e) {
      errors.push({ row: i + 1, message: (e as Error).message });
    }
  });
  return { activities, errors, duplicates };
}

import { Activity, LocalState, RejectionReason } from "./models";
export function planOrSave(
  s: LocalState,
  a: Activity,
  status: "planned" | "saved",
): LocalState {
  return {
    ...s,
    adventures: [
      ...s.adventures.filter((x) => x.activityId !== a.id),
      {
        activityId: a.id,
        activity: a,
        status,
        updatedAt: new Date().toISOString(),
      },
    ],
  };
}
export function dismiss(
  s: LocalState,
  id: string,
  reason?: RejectionReason,
): LocalState {
  return {
    ...s,
    feedback: [
      ...s.feedback,
      {
        activityId: id,
        kind: "dismissed",
        reason,
        at: new Date().toISOString(),
      },
    ],
  };
}
export function complete(
  s: LocalState,
  a: Activity,
  reaction?: string,
  reflection?: string,
): LocalState {
  const at = new Date().toISOString();
  return {
    ...s,
    adventures: [
      ...s.adventures.filter((x) => x.activityId !== a.id),
      { activityId: a.id, activity: a, status: "completed", updatedAt: at },
    ],
    completions: [
      ...s.completions.filter((x) => x.activityId !== a.id),
      {
        activityId: a.id,
        completedAt: at,
        reaction,
        reflection: reflection?.trim().slice(0, 1000),
      },
    ],
    feedback: reaction
      ? [...s.feedback, { activityId: a.id, kind: "reaction", reaction, at }]
      : s.feedback,
  };
}

export type Mood = "Surprise me" | "Chill" | "Social" | "Active" | "Creative";
export type Challenge = "Easy" | "Moderate" | "Stretch";
export interface ActivitySource {
  platform: "curated" | "instagram" | "organizer";
  url?: string;
  sourceId?: string;
  publishedAt?: string;
}
export interface Venue {
  name?: string;
  city?: string;
  address?: string;
  latitude?: number;
  longitude?: number;
}
export interface Activity {
  id: string;
  type: "evergreen" | "event";
  title: string;
  description: string;
  category: string;
  moods: Mood[];
  venue?: Venue;
  startTime?: string;
  endTime?: string;
  timeZone?: string;
  durationMinutes?: number;
  price?: number;
  currency?: string;
  priceStatus?: "estimated" | "verified";
  source: ActivitySource;
  verification: "demo" | "unverified" | "verified";
  lastCheckedAt?: string;
  imageUrl?: string;
  challenge: Challenge;
  availability: "unknown" | "available" | "unavailable" | "full";
  whatToExpect?: string;
  whyTry?: string;
  openingInfo?: string;
  restrictions?: string;
}
export interface UserPreferences {
  location: string;
  latitude?: number;
  longitude?: number;
  mood: Mood;
  interests: string[];
  budget: number;
  distanceKm: number;
  timeMinutes: number;
  maxChallenge: Challenge;
  onboarded: boolean;
}
export type RejectionReason =
  | "Too expensive"
  | "Too far away"
  | "Wrong timing"
  | "Not available or fully booked"
  | "Not my thing";
export interface ActivityFeedback {
  activityId: string;
  kind: "dismissed" | "reaction";
  reason?: RejectionReason;
  reaction?: string;
  at: string;
}
export interface CompletedQuest {
  activityId: string;
  completedAt: string;
  reaction?: string;
  reflection?: string;
}
export interface Adventure {
  activityId: string;
  status: "saved" | "planned" | "completed";
  updatedAt: string;
  activity: Activity;
}
export interface LocalState {
  preferences: UserPreferences;
  adventures: Adventure[];
  feedback: ActivityFeedback[];
  completions: CompletedQuest[];
}
export const defaults: UserPreferences = {
  location: "",
  mood: "Surprise me",
  interests: [],
  budget: 30,
  distanceKm: 10,
  timeMinutes: 120,
  maxChallenge: "Moderate",
  onboarded: false,
};
export const emptyState = (): LocalState => ({
  preferences: { ...defaults },
  adventures: [],
  feedback: [],
  completions: [],
});

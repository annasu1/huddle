import { Activity, LocalState } from "./models";
export function distanceKm(a: Activity, state: LocalState): number | undefined {
  const p = state.preferences,
    v = a.venue;
  if (
    p.latitude == null ||
    p.longitude == null ||
    v?.latitude == null ||
    v.longitude == null
  )
    return;
  const rad = (n: number) => (n * Math.PI) / 180;
  const x =
    Math.sin(rad(v.latitude - p.latitude) / 2) ** 2 +
    Math.cos(rad(p.latitude)) *
      Math.cos(rad(v.latitude)) *
      Math.sin(rad(v.longitude - p.longitude) / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}
export function recommend(
  catalog: Activity[],
  state: LocalState,
  now = Date.now(),
  exclude: string[] = [],
): { activity: Activity; reason: string }[] {
  const p = state.preferences,
    levels = ["Easy", "Moderate", "Stretch"];
  const distinct = catalog.filter(
    (a, i) => catalog.findIndex((b) => b.id === a.id) === i,
  );
  const scored = distinct
    .filter((a) => {
      if (
        exclude.includes(a.id) ||
        ["full", "unavailable"].includes(a.availability)
      )
        return false;
      if (
        a.type === "event" &&
        (!a.startTime ||
          !Number.isFinite(Date.parse(a.startTime)) ||
          Date.parse(a.endTime || a.startTime) <= now)
      )
        return false;
      if (
        state.adventures.some(
          (q) => q.activityId === a.id && q.status !== "saved",
        ) ||
        state.completions.some((q) => q.activityId === a.id)
      )
        return false;
      if (
        state.feedback.some(
          (f) =>
            f.activityId === a.id &&
            f.kind === "dismissed" &&
            now - Date.parse(f.at) < 30 * 86400000,
        )
      )
        return false;
      if (
        a.verification !== "demo" &&
        a.venue?.city &&
        p.location &&
        p.latitude == null &&
        a.venue.city.toLowerCase() !== p.location.toLowerCase()
      )
        return false;
      const d = distanceKm(a, state);
      return (
        !(
          a.price != null &&
          a.price > 0 &&
          a.currency != null &&
          a.currency !== "USD"
        ) &&
        !(a.price != null && a.currency === "USD" && a.price > p.budget) &&
        !(a.durationMinutes != null && a.durationMinutes > p.timeMinutes) &&
        !(d != null && d > p.distanceKm) &&
        levels.indexOf(a.challenge) <= levels.indexOf(p.maxChallenge)
      );
    })
    .map((a) => {
      let score = 0;
      const reasons: string[] = [];
      if (a.moods.includes(p.mood)) {
        score += 5;
        reasons.push(`A little more ${p.mood.toLowerCase()} in your day`);
      }
      if (p.interests.includes(a.category)) {
        score += 3;
        reasons.push("Something you enjoy");
      }
      if (a.price != null && a.price <= p.budget) {
        score += 2;
        reasons.push("Fits your budget");
      }
      if (a.verification === "verified") score += 2;
      if (a.lastCheckedAt && now - Date.parse(a.lastCheckedAt) < 7 * 86400000)
        score++;
      if (
        a.source.publishedAt &&
        now - Date.parse(a.source.publishedAt) < 7 * 86400000
      )
        score++;
      for (const f of state.feedback) {
        const related = catalog.find((b) => b.id === f.activityId);
        if (related?.category === a.category) {
          if (f.reason === "Not my thing" || f.reaction === "😕") score -= 3;
          if (f.reaction === "💛" || f.reaction === "🤩") score += 2;
        }
      }
      if (a.challenge === "Easy") score++;
      return {
        activity: a,
        score,
        reason: reasons[0] || "A small change of scenery",
      };
    })
    .sort(
      (a, b) => b.score - a.score || a.activity.id.localeCompare(b.activity.id),
    );
  // Greedy variety penalty keeps three strong matches without three near-identical ideas.
  const chosen: typeof scored = [];
  while (scored.length && chosen.length < 3) {
    scored.sort(
      (a, b) =>
        b.score -
        (chosen.some((x) => x.activity.category === b.activity.category)
          ? 5
          : 0) -
        (a.score -
          (chosen.some((x) => x.activity.category === a.activity.category)
            ? 5
            : 0)),
    );
    chosen.push(scored.shift()!);
  }
  return chosen.map(({ activity, reason }) => ({ activity, reason }));
}

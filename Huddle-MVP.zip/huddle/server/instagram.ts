/** SERVER ONLY scaffold. Intentionally never imported by app/ or src/. */
import { normalizeMany } from "../src/domain/normalize";
export interface SourceAdapter {
  discover(): Promise<{ candidates: unknown[]; warnings: string[] }>;
}
export class InstagramApifyAdapter implements SourceAdapter {
  constructor(
    private token: string,
    private urls: string[],
    private fetcher: typeof fetch = fetch,
  ) {}
  async discover() {
    if (!this.token || !this.urls.length)
      throw Error("Configure APIFY_API_TOKEN and Instagram URLs on the server");
    // No token in a URL or log. Bounded synchronous run; no autonomous scheduler.
    const res = await this.fetcher(
      "https://api.apify.com/v2/acts/apify~instagram-scraper/run-sync-get-dataset-items?timeout=60&memory=1024",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          directUrls: this.urls,
          resultsType: "posts",
          resultsLimit: 20,
        }),
        signal: AbortSignal.timeout(70000),
      },
    );
    if (res.status === 429)
      throw Error("Apify rate limited the request; retry later.");
    if (!res.ok)
      throw Error(
        `Apify request failed (${res.status}). Check the actor run before retrying to avoid duplicate charges.`,
      );
    const rows: unknown = await res.json();
    if (!Array.isArray(rows)) throw Error("Malformed Apify response");
    const candidates = rows
      .filter((r): r is Record<string, unknown> => !!r && typeof r === "object")
      .filter((r) => typeof r.caption === "string" && typeof r.url === "string")
      .map((r) => ({
        source: {
          platform: "instagram",
          sourceId: r.id,
          url: r.url,
          publishedAt: r.timestamp,
        },
        caption: r.caption,
        reviewStatus: "candidate",
        verification: "unverified",
      }));
    return {
      candidates,
      warnings: [
        "Posts are discovery candidates only. No event dates, costs, venue, or availability inferred. Human review required before normalization and publication.",
      ],
    };
  }
}
// Shared publishing boundary: reviewer supplies actual activity facts and a stable ID.
export const validateReviewedActivities = normalizeMany;

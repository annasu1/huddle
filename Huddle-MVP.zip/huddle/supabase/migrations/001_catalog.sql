-- Only public catalog data. Never write device history or private reflections here.
create table public.activities (
 id text primary key,
 payload jsonb not null,
 published boolean not null default false,
 updated_at timestamptz not null default now(),
 constraint payload_id_matches check (payload->>'id' = id),
 constraint payload_required check (payload ?& array['id','type','title','description','category']),
 constraint activity_type check (payload->>'type' in ('event','evergreen'))
);
alter table public.activities enable row level security;
revoke all on public.activities from anon, authenticated;
grant select on public.activities to anon, authenticated;
create policy "Published catalog is readable" on public.activities for select to anon, authenticated using (published = true);
-- No client insert/update/delete policy. Trusted administration uses a server-only
-- service-role key (bypasses RLS). Validate payload before publishing.
create index activities_published on public.activities(published) where published = true;

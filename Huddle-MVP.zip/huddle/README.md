# Huddle

**Less scrolling. More living.** An account-free Expo/React Native MVP that offers three practical ideas, then gets out of your way. Includes an original app-owned SVG penguin, warm ivory/sky/peach theme, optional interests, and private adventure memories.

## Quick start

Prerequisites: Node 22 LTS (Node 24 also validated), npm, and an iOS/Android development environment or compatible Expo client. Initial dependency installation needs internet.

```sh
npm ci
npm start
# Or browser preview:
npm run web
```

No `.env` is required. The included sample ideas work without any API credentials. For a simulator/device development build, use `npm run ios` (macOS/Xcode) or `npm run android` (Android Studio/SDK). SDK 54 is pinned intentionally; use an SDK-54-compatible Expo Go client or a development build if your current Expo Go no longer supports it.

For a fully offline installed app, create a **release** native build with the JS bundle embedded, e.g. `npx expo run:android --variant release` or `npx expo run:ios --configuration Release`. Native build tools, dependencies, signing, and initial installation require their usual setup. A development Expo session depends on Metro; it is not a standalone offline install. Web is a preview, not an installable offline PWA.

## Product flow

1. Enter a city/area. Optional foreground location permission adds coordinates; no registration or interest questionnaire.
2. Choose Surprise me, Chill, Social, Active, or Creative. Defaults: $30 USD, 10 km, two hours, up to Moderate challenge.
3. Receive three eligible distinct recommendations, or an honest limited-results state. “Three more” pages through this session’s candidates, never an endless feed.
4. Reject with an optional reason, inspect details, or save for later.
5. Plan with “I’ll try this” / “I’m going.” Home focuses on the first active plan. Plans can be canceled and discovery is always available.
6. Mark a planned activity complete, optionally add an emoji and private reflection. No proof or check-in.
7. Review Saved, Planned, Completed. Export JSON or confirm history deletion in Settings.

“Try this” opens details, not a commitment. Sample events are explicitly fictional; no tickets are booked by planning. Everyday sample ideas are generic, not purported verified venues. One synthetic upcoming demo event is dated seven days after catalog construction solely to exercise event UI; other fixtures intentionally represent expired/full events. No fabricated address or organizer link is shown.

## Commands and validation

```sh
npm test                 # node:test via TypeScript loader
npm run typecheck
npm run lint
npx expo install --check
npm run export:web
npx expo export --platform ios --platform android
npm run import -- samples/activities.csv /tmp/activities.json
```

The tests cover exact-three/limited results, hard filters, coordinates, eligibility, expiry, novelty/diversity, category adaptation, optional field sanitization, deduplication, plan/cancel/completion transitions, Supabase failure fallback, and Apify candidate handling. See `VALIDATION.md` for checks actually executed. Bundle exports are not signed device builds or device QA.

## Architecture

| Module | Responsibility |
| --- | --- |
| `app/` | Expo Router screens: onboarding/home, quests, details, adventures, settings |
| `src/components/` | Accessible shared controls, filters, activity card, original vector mascot, theme |
| `src/domain/models.ts` | Typed activities/sources/venues/preferences/feedback/completions/local state |
| `src/domain/recommend.ts` | Pure eligibility, scoring, distance, and diversity logic |
| `src/domain/actions.ts` | Pure saved/planned/completed/dismissed state transitions |
| `src/domain/normalize.ts` | Untrusted-data normalization, validation, URL canonicalization, deduplication |
| `src/data/` | Labeled fixtures and optional imported local catalog |
| `src/services/catalog.ts` | `CatalogRepository`, `DemoRepository`, Supabase REST adapter and fallback |
| `src/services/storage.ts` | Native Expo SQLite persistence, parameterized SQL |
| `src/services/storage.web.ts` | Browser-only localStorage preview adapter |
| `src/services/export.ts` | Native JSON share sheet / browser download |
| `src/state/AppState.tsx` | Hydration, serialized durable writes, catalog loading and errors |
| `scripts/import.ts` | CSV/JSON import CLI |
| `server/instagram.ts` | Optional server-only source adapter/scaffold |
| `supabase/migrations/` | Public catalog schema and read-only RLS |
| `tests/` | Core and integration-boundary tests |

No auth SDK, AI model, backend user accounts, scheduler, or PostGIS needed. Geographic distance is computed locally with the haversine formula.

### Data model

`Activity` separates `event` from `evergreen`, includes a stable ID, title, category, description, moods, source, verification, availability and challenge. Optional fields include venue/address/coordinates, event timestamps/time zone, duration, price/currency, image, opening info, restrictions and last-check time. Source publication time is separate from event time. Currency codes are not converted.

`ActivitySource` preserves platform, source ID, canonical source URL and publication timestamp. `Venue` holds optional location facts. `UserPreferences` contains filters and optional coordinates/interests. `ActivityFeedback` stores rejection/reaction and timestamp. `CompletedQuest` stores an optional reaction/reflection. `Adventure` stores status and a full activity snapshot, keeping local history readable even if a catalog entry disappears.

### Recommendation rules

Known costs (USD), durations, distances and maximum challenge are hard constraints. Known positive non-USD prices are excluded because no conversion is available. Missing optional values stay eligible and are explicitly displayed as unknown. Unknown cost cannot be guaranteed to fit budget. Manual location is not geocoded: real catalog entries with a known city require an exact case-insensitive city match when coordinates are absent; use a city name rather than a neighborhood for such catalogs. Generic demo ideas work anywhere. With coordinates, known distances govern eligibility; unknown distances remain disclosed.

Expired, fully booked, unavailable, already planned, completed and recently dismissed activities are excluded. Dismissals cool down for 30 days; completions are not repeated until history is deleted. Missing/invalid event start times are ineligible. Ranking rewards mood, interests, known affordable cost, easy challenges, recent publication/checks and verification. Positive/negative reactions and “Not my thing” alter category scores. Other rejection reasons suppress that item without silently changing the user’s stated filters. A greedy category repetition penalty adds variety within the eligible set. Session pagination excludes seen IDs, with an explicit revisit action.

No availability is inferred from catalog presence. “Verified” means the supplied source information was reviewed, not that space is still bookable. Recheck organizers before attending. Challenge labels are broad publisher-supplied assessments of novelty, effort, social exposure and commitment, not a psychological assessment.

### Local persistence and privacy

Native SQLite uses WAL and a version-1 `kv` table: one atomic JSON document for private state, and a separate catalog cache. This is deliberate MVP simplicity; business types remain separate in TypeScript. Queued writes commit before updating UI. Local failure surfaces an error instead of falsely reporting success. SQLite is device-local, not encrypted by this app; platform backup policies may apply. Reflections never enter Supabase. Permissions are requested only after a tap, and no background location is collected.

No analytics, telemetry SDK, tracking IDs, push notifications, streaks, public profiles, or social sharing prompts. The JSON export includes private history and excludes location/preferences. Native export temporary files are deleted after sharing. History deletion keeps preferences and public catalog cache. Settings can forget precise coordinates. Uninstall/clear browser storage can remove all local data; exporting is recommended before doing so. JSON restore is not implemented.

The native app has no required network requests in demo mode. Supabase refresh times out after six seconds and uses the cached catalog, then demo data if no cache exists. The interface announces demo, refreshed, or fallback status. Demo mode is network-independent; it does not attempt to infer your device’s actual connection state. External source/directions links require connectivity. Cached events are still checked for expiration locally.

## Supabase setup (optional)

1. Create a Supabase project. Run `supabase/migrations/001_catalog.sql` in the SQL editor or your migration workflow.
2. Copy `.env.example` to `.env` and set `EXPO_PUBLIC_SUPABASE_URL` and the **public anon/read-only key**. Restart Metro after env changes. Use HTTPS.
3. Import/normalize a catalog as below. A trusted admin uses SQL or a server-only service role to upsert rows `{ id, payload: Activity, published: false }`.
4. Review facts, source URLs, date/time zones, price status, last-checked timestamps and availability. Set `published=true` only on intended public records. Instagram candidates must be reviewed first.

RLS permits `anon`/`authenticated` SELECT only when published. Client INSERT/UPDATE/DELETE grants are revoked and no write policies exist. The service role bypasses RLS and must never be bundled into the app. No private user table exists. Suggested policy verification: with the anon key, published rows should return, unpublished IDs should not, and POST/PATCH/DELETE must fail. Live policies have not been exercised without a configured project.

The repository uses Supabase’s PostgREST endpoint, not a client auth SDK. A successful empty catalog produces empty results, not invented activities. Malformed catalog responses fall back. For larger catalogs add paging and server-side city filtering; the MVP fetches one server-default page. No precise user coordinates are sent with catalog requests.

## CSV / JSON import

```sh
# Validate and write usable local catalog content:
npm run import -- samples/activities.csv src/data/imported.json
# JSON uses the same normalizer:
npm run import -- samples/activities.json /tmp/catalog.json
```

Imported records are merged ahead of demo fixtures by `DemoRepository`. Replace/remove the demo merge for a non-demo production catalog. Rebuild/restart after changes. Output is a normalized array, not a direct database upload. The importer never publishes data automatically.

JSON input is an array with the `Activity` structure. CSV uses a header row; required columns: `id,type,title,description,category`. Optional CSV columns: `moods` (pipe-delimited), `venueName,city,address,latitude,longitude,startTime,endTime,timeZone,durationMinutes,price,currency,sourceUrl,sourcePlatform,sourceId,publishedAt,verification,lastCheckedAt,challenge,availability,openingInfo,whatToExpect,whyTry,restrictions,imageUrl,priceStatus`. Events require a valid start timestamp; any supplied end must be valid and after start. Prefer complete ISO timestamps with offsets and IANA time zones. Prices/durations must be nonnegative/positive. Invalid optional numbers, dates, coordinates or URLs become unknown; invalid required fields are reported with one-based **data row** numbers. Exit 2 means valid rows were written but some rows were rejected; exit 1 means input/file failure. Inspect errors before publishing.

Deduplication checks stable ID, platform/source ID, canonical URL (removing fragment and `utm_*`) and a conservative normalized title/city/start-time match. It keeps the first occurrence. Review false positives for recurring evergreen activities. `verification=verified` is a trusted-admin assertion; parsing never proves it. Use demo or unverified unless a human actually checks the facts.

## Apify / Instagram (optional, server only)

No credentials were available, so this is an explicitly documented, mock-tested integration scaffold—not a live-verified Instagram pipeline. `InstagramApifyAdapter` implements `SourceAdapter.discover()` and calls `apify/instagram-scraper` with bounded post results. Configure only in a server shell: `APIFY_API_TOKEN`, `APIFY_INSTAGRAM_URLS` (comma-separated URLs). Do **not** use `EXPO_PUBLIC_` for secrets. Never import `server/` from app code.

Example trusted server script:

```ts
import { InstagramApifyAdapter } from './server/instagram';
const source = new InstagramApifyAdapter(
  process.env.APIFY_API_TOKEN!,
  process.env.APIFY_INSTAGRAM_URLS!.split(',').map(x => x.trim()).filter(Boolean),
);
const { candidates, warnings } = await source.discover();
// Persist to a private review queue/file. Do not publish candidates directly.
```

Candidate objects contain original captions and source metadata only. The adapter does not guess event titles, dates, prices, venue, or availability from prose. A human creates a reviewed Activity and passes it through `validateReviewedActivities` (shared normalization/deduplication) before publication. Posts are not valid events merely because they were recently published. The response normalizer drops malformed posts; HTTP/rate-limit errors are explicit. No automatic retries are made because retrying a run can incur duplicate charges; inspect the Apify console first. Timeout is bounded. Actor input/output schemas may change: verify against the actor’s current documentation before using paid credentials.

Public Instagram content can be incomplete, blocked, removed, stale or inaccessible without authentication. Actor availability and platform permissions are not guaranteed. Respect Instagram/Apify terms, access restrictions, privacy and content rights; ingest only material you are authorized to process. Never bypass access controls. See https://apify.com/apify/instagram-scraper and https://docs.apify.com/api/v2.

## Accessibility and limitations

Controls use readable text, 46–54+ point touch targets, labels, selected-state semantics, flexible wrapping and safe areas. Forms use explicit accessible labels. There are no animated rewards or navigation transitions, so reduced-motion users receive the same calm experience. Screen-reader behavior, very large text, and platform permission dialogs still need device QA.

Not included: booking/payment, real venue verification, geocoding offline city names, live opening hours, push notifications, cloud user sync, restore imports, background refresh, map tiles, image caching, currency conversion, autonomous Instagram extraction, or a signed app-store build. These are explicit extension points behind the repository, source, and storage boundaries. Keep the three-choice flow and user-controlled commitments when extending the app.

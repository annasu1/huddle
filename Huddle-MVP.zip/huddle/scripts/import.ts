import { readFileSync, writeFileSync } from "node:fs";
import { parse } from "csv-parse/sync";
import { normalizeMany } from "../src/domain/normalize";
const [input, output = "activities.normalized.json"] = process.argv.slice(2);
if (!input) {
  console.error("Usage: npm run import -- input.csv|input.json [output.json]");
  process.exit(1);
}
try {
  const text = readFileSync(input, "utf8");
  const rows: unknown = input.endsWith(".csv")
    ? parse(text, { columns: true, skip_empty_lines: true, bom: true })
    : JSON.parse(text);
  if (!Array.isArray(rows)) throw Error("Input must be an array of records");
  const result = normalizeMany(rows);
  writeFileSync(output, JSON.stringify(result.activities, null, 2));
  console.log(
    JSON.stringify(
      {
        imported: result.activities.length,
        duplicates: result.duplicates,
        errors: result.errors,
        output,
      },
      null,
      2,
    ),
  );
  if (result.errors.length) process.exitCode = 2;
} catch (e) {
  console.error((e as Error).message);
  process.exitCode = 1;
}

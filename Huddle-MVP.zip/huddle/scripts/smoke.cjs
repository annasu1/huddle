const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || undefined,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://127.0.0.1:8081");
  await page.getByLabel("City or area").fill("San Francisco");
  await page.context().setOffline(true);
  await page.screenshot({ path: "/tmp/huddle-welcome.png" });
  await page.getByRole("button", { name: "Let's go →", exact: true }).click();
  await page
    .getByRole("button", { name: "Find my next quest →", exact: true })
    .waitFor();
  await page.screenshot({ path: "/tmp/huddle-home.png" });
  await page
    .getByRole("button", { name: "Find my next quest →", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Try this ↗", exact: true })
    .first()
    .waitFor();
  if (
    (await page
      .getByRole("button", { name: "Try this ↗", exact: true })
      .count()) !== 3
  )
    throw Error("Expected 3 cards");
  await page
    .getByRole("button", { name: "Not for me", exact: true })
    .first()
    .click();
  await page.getByRole("button", { name: "Not my thing", exact: true }).click();
  await page
    .getByRole("button", { name: "Try this ↗", exact: true })
    .first()
    .click();
  await page
    .getByRole("button", { name: "Save for later ♡", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Remove from saved", exact: true })
    .waitFor();
  await page
    .getByRole("button", { name: "I'll try this →", exact: true })
    .click();
  await page.getByRole("button", { name: "I did it ✓", exact: true }).waitFor();
  await page.context().setOffline(false);
  await page.goto("http://127.0.0.1:8081");
  await page
    .getByRole("button", { name: "Open my adventure →", exact: true })
    .waitFor();
  await page.context().setOffline(true);
  await page
    .getByRole("button", { name: "Open my adventure →", exact: true })
    .click();
  await page.getByRole("button", { name: "Cancel plan", exact: true }).click();
  await page
    .getByRole("button", { name: "I'll try this →", exact: true })
    .click();
  await page.getByRole("button", { name: "I did it ✓", exact: true }).click();
  await page.getByRole("button", { name: "💛", exact: true }).click();
  await page.getByLabel("Private reflection").fill("A little joy outside.");
  await page
    .getByRole("button", { name: "Complete adventure", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Back to my adventures", exact: true })
    .click();
  await page.getByRole("button", { name: /Completed · 1/ }).click();
  await page
    .getByRole("button", { name: "Open adventure →", exact: true })
    .waitFor();
  await page.screenshot({ path: "/tmp/huddle-history.png" });
  await page.getByRole("button", { name: /Settings/ }).click();
  const download = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Export history as JSON ↗", exact: true })
    .click();
  await (await download).saveAs("/tmp/huddle-export.json");
  const exported = JSON.parse(
    require("fs").readFileSync("/tmp/huddle-export.json", "utf8"),
  );
  if (exported.completions[0].reflection !== "A little joy outside.")
    throw Error("Reflection missing from export");
  await page
    .getByRole("button", { name: "Delete local history", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Keep my history", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Delete local history", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Yes, delete my history", exact: true })
    .click();
  await page
    .getByText("History deleted. A fresh start.", { exact: true })
    .waitFor();
  const state = await page.evaluate(() =>
    JSON.parse(localStorage.getItem("huddle:state")),
  );
  if (state.completions.length) throw Error("Delete failed");
  if (errors.length) throw Error(errors.join("\n"));
  console.log(
    "PASS: onboarding, three recommendations, rejection, save, plan, complete, reflection, history, export, confirmed deletion; reload persistence, cancellation, network disabled during interactions; no browser errors",
  );
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});

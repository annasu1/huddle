import { useState } from "react";
import { View, Text } from "react-native";
import { router } from "expo-router";
import { useHuddle } from "../src/state/AppState";
import {
  Page,
  Title,
  Body,
  Card,
  Chip,
  Button,
  Penguin,
  s,
  colors,
} from "../src/components/ui";
export default function Adventures() {
  const { state } = useHuddle();
  const [filter, setFilter] = useState<"saved" | "planned" | "completed">(
    "planned",
  );
  const rows = state.adventures.filter((q) => q.status === filter);
  return (
    <Page tab="Adventures">
      <Text style={s.tag}>YOUR LITTLE COLLECTION</Text>
      <Title>My adventures</Title>
      <Body>Things to look forward to. Moments to look back on.</Body>
      <View style={s.row}>
        {(["saved", "planned", "completed"] as const).map((f) => (
          <Chip
            key={f}
            label={`${f[0].toUpperCase() + f.slice(1)} · ${state.adventures.filter((a) => a.status === f).length}`}
            selected={f === filter}
            onPress={() => setFilter(f)}
          />
        ))}
      </View>
      {rows.length === 0 ? (
        <Card>
          <Penguin size={130} />
          <Text style={s.subtitle}>Room for a little adventure.</Text>
          <Body>No {filter} activities yet. Go at your own pace.</Body>
          <Button onPress={() => router.push("/")}>Discover something</Button>
        </Card>
      ) : (
        rows.map((q) => (
          <Card key={q.activityId}>
            <Text style={s.tag}>{q.activity.category}</Text>
            <Text style={s.subtitle}>{q.activity.title}</Text>
            <Body>{new Date(q.updatedAt).toLocaleDateString()}</Body>
            <Button
              secondary
              onPress={() =>
                router.push({
                  pathname: "/activity/[id]",
                  params: { id: q.activityId },
                })
              }
            >
              Open adventure →
            </Button>
          </Card>
        ))
      )}
      {state.completions.length > 0 && (
        <Card tint={colors.blue}>
          <View style={s.row}>
            {Array.from({ length: Math.min(3, state.completions.length) }).map(
              (_, i) => (
                <Penguin key={i} size={70} />
              ),
            )}
          </View>
          <Text style={s.subtitle}>A cozy little huddle.</Text>
          <Body>
            {state.completions.length} adventure
            {state.completions.length !== 1 ? "s" : ""} remembered. Your penguin
            friends are happy you got out there.
          </Body>
        </Card>
      )}
    </Page>
  );
}

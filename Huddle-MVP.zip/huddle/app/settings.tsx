import { useState } from "react";
import { View, Text } from "react-native";
import { useHuddle } from "../src/state/AppState";
import {
  Page,
  Title,
  Body,
  Label,
  Field,
  Button,
  Chip,
  Card,
  s,
  colors,
} from "../src/components/ui";
import { Filters } from "../src/components/Filters";
import { exportHistory } from "../src/services/export";
export default function Settings() {
  const { state, update } = useHuddle();
  const [p, setP] = useState(state.preferences),
    [confirm, setConfirm] = useState(false),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <Page tab="Settings">
      <Text style={s.tag}>MAKE YOURSELF AT HOME</Text>
      <Title>Your kind of adventure.</Title>
      <View>
        <Label>City or area</Label>
        <Field
          accessibilityLabel="Location"
          value={p.location}
          onChangeText={(location) =>
            setP({ ...p, location, latitude: undefined, longitude: undefined })
          }
          maxLength={100}
        />
      </View>
      <Body>
        {p.latitude != null
          ? "Coordinates are stored locally for distance estimates."
          : "Manual location: distances are unknown until coordinates are supplied. Demo ideas work anywhere."}
      </Body>
      <Button
        secondary
        onPress={() => {
          setP({ ...p, latitude: undefined, longitude: undefined });
          setMessage(
            "Coordinates removed from this draft. Save preferences to apply.",
          );
        }}
      >
        Forget precise location
      </Button>
      <Filters value={p} onChange={setP} />
      <View>
        <Label>Interests · optional</Label>
        <View style={s.row}>
          {[
            "Outdoors",
            "Creative",
            "Food",
            "Culture",
            "Social",
            "Nature",
            "Movement",
          ].map((i) => (
            <Chip
              key={i}
              label={i}
              selected={p.interests.includes(i)}
              onPress={() =>
                setP({
                  ...p,
                  interests: p.interests.includes(i)
                    ? p.interests.filter((x) => x !== i)
                    : [...p.interests, i],
                })
              }
            />
          ))}
        </View>
      </View>
      <View>
        <Label>Maximum challenge</Label>
        <View style={s.row}>
          {(["Easy", "Moderate", "Stretch"] as const).map((c) => (
            <Chip
              key={c}
              label={c}
              selected={p.maxChallenge === c}
              onPress={() => setP({ ...p, maxChallenge: c })}
            />
          ))}
        </View>
      </View>
      <Button
        disabled={!p.location.trim() || busy}
        onPress={() => {
          setBusy(true);
          void update((s) => ({
            ...s,
            preferences: { ...p, location: p.location.trim() },
          }))
            .then(() => setMessage("Preferences saved."))
            .catch(() => {})
            .finally(() => setBusy(false));
        }}
      >
        Save preferences
      </Button>
      <Card>
        <Text style={s.subtitle}>Your memories stay yours.</Text>
        <Body>
          Your preferences, history, reactions, and reflections stay on this
          device. No account, analytics, advertising identifiers, or background
          location tracking.
        </Body>
        <Body>
          Optional catalog refreshes send your IP address to your configured
          catalog provider. Opening directions or source links uses external
          services. Exporting creates a private JSON file—choose where you share
          it.
        </Body>
        <Button
          secondary
          onPress={() => {
            void exportHistory(state)
              .then(() => setMessage("Export ready."))
              .catch(() =>
                setMessage(
                  "Export failed. Check that downloads or sharing are supported.",
                ),
              );
          }}
        >
          Export history as JSON ↗
        </Button>
        <Button secondary onPress={() => setConfirm(true)}>
          Delete local history
        </Button>
      </Card>
      {confirm && (
        <Card tint={colors.peach}>
          <Text style={s.subtitle}>Delete your activity history?</Text>
          <Body>
            This permanently removes saved plans, completions, reactions, and
            reflections on this device. Preferences remain. Export first if you
            want a copy.
          </Body>
          <Button
            disabled={busy}
            onPress={() => {
              setBusy(true);
              void update((s) => ({
                ...s,
                adventures: [],
                feedback: [],
                completions: [],
              }))
                .then(() => {
                  setConfirm(false);
                  setMessage("History deleted. A fresh start.");
                })
                .catch(() => {})
                .finally(() => setBusy(false));
            }}
          >
            Yes, delete my history
          </Button>
          <Button secondary onPress={() => setConfirm(false)}>
            Keep my history
          </Button>
        </Card>
      )}
      {message && (
        <Text accessibilityLiveRegion="polite" style={s.body}>
          {message}
        </Text>
      )}
    </Page>
  );
}

import { useState } from "react";
import { View, Text, Linking } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { useHuddle } from "../../src/state/AppState";
import { planOrSave, complete } from "../../src/domain/actions";
import {
  Page,
  Title,
  Body,
  Card,
  Button,
  Chip,
  Field,
  Penguin,
  s,
  colors,
} from "../../src/components/ui";
import { priceLabel } from "../../src/components/ActivityCard";
export default function Details() {
  const { id, reason } = useLocalSearchParams<{
    id: string;
    reason?: string;
  }>();
  const { catalog, state, update } = useHuddle();
  const a =
    catalog.find((a) => a.id === id) ||
    state.adventures.find((q) => q.activityId === id)?.activity;
  const q = state.adventures.find((q) => q.activityId === id),
    done = state.completions.find((q) => q.activityId === id);
  const [finishing, setFinishing] = useState(false),
    [reaction, setReaction] = useState<string>(),
    [reflection, setReflection] = useState(""),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  if (!a)
    return (
      <Page back>
        <Title>Idea unavailable</Title>
        <Body>This activity isn’t in the current catalog.</Body>
        <Button onPress={() => router.replace("/")}>Back home</Button>
      </Page>
    );
  const unavailable =
    ["full", "unavailable"].includes(a.availability) ||
    (a.type === "event" &&
      (!a.startTime || Date.parse(a.endTime || a.startTime) <= Date.now()));
  async function action(fn: Parameters<typeof update>[0], success: string) {
    setBusy(true);
    try {
      await update(fn);
      setMessage(success);
      return true;
    } catch {
      return false;
    } finally {
      setBusy(false);
    }
  }
  async function open(url: string) {
    try {
      await Linking.openURL(url);
    } catch {
      setMessage("Could not open this link. Try again when you are online.");
    }
  }
  return (
    <Page back>
      <Text style={s.tag}>
        {a.category} · {a.challenge} challenge
      </Text>
      <Title>{a.title}</Title>
      {q?.status === "planned" && (
        <Card tint={colors.blue}>
          <Text style={s.subtitle}>This one’s yours.</Text>
          <Body>
            Put your phone away when you’re ready. No check-ins, no proof
            needed.
          </Body>
        </Card>
      )}
      {q?.status === "completed" && (
        <Card tint={colors.green}>
          <Penguin size={100} />
          <Text style={s.subtitle}>A little adventure, well lived.</Text>
          <Body>
            {done?.reaction || "♡"}{" "}
            {done?.reflection ||
              "You made a little room for something different."}
          </Body>
        </Card>
      )}
      <Body>{a.description}</Body>
      <Card>
        <Text style={s.subtitle}>The little details</Text>
        <Body>
          {priceLabel(a)}{" "}
          {a.priceStatus === "estimated"
            ? "· estimate, not a quoted price"
            : ""}
        </Body>
        <Body>
          {a.durationMinutes
            ? `About ${a.durationMinutes} minutes`
            : "Duration unknown"}
        </Body>
        <Body>
          {a.venue?.name || "Choose a suitable local spot"}
          {a.venue?.address ? `\n${a.venue.address}` : ""}
          {a.venue?.city ? `\n${a.venue.city}` : ""}
        </Body>
        <Body>
          {a.type === "event"
            ? `${a.startTime ? new Date(a.startTime).toLocaleString() : "Date unknown"}${a.endTime ? ` – ${new Date(a.endTime).toLocaleString()}` : ""}\nEvent zone: ${a.timeZone || "unknown"} · displayed in device time`
            : a.openingInfo || "Opening information unknown"}
        </Body>
        <Body>
          {a.restrictions ||
            "Restrictions and accessibility details unknown. Check suitability before going."}
        </Body>
        {(a.venue?.address || a.venue?.latitude != null) && (
          <Button
            secondary
            onPress={() =>
              void open(
                `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.venue?.address || `${a.venue?.latitude},${a.venue?.longitude}`)}`,
              )
            }
          >
            Open directions ↗
          </Button>
        )}
      </Card>
      <Text style={s.subtitle}>What to expect</Text>
      <Body>
        {a.whatToExpect || "Check the original source for practical details."}
      </Body>
      <Text style={s.subtitle}>Why give it a go?</Text>
      <Body>
        {reason ||
          a.whyTry ||
          "A chance to explore something outside your routine."}
      </Body>
      <Body>
        {a.challenge === "Easy"
          ? "Easy: low effort or commitment."
          : a.challenge === "Moderate"
            ? "Moderate: a little more novelty, effort, or social time."
            : "Stretch: more effort, novelty, or commitment. Choose what feels comfortable."}
      </Body>
      <Card tint={colors.peach}>
        <Text style={s.label}>
          {a.verification === "demo"
            ? "SAMPLE CONTENT"
            : `${a.verification.toUpperCase()} INFORMATION`}
        </Text>
        <Body>
          {a.verification === "demo"
            ? "This is a sample idea, not a verified venue or bookable listing. Costs and durations are illustrative estimates."
            : `Source: ${a.source.platform}. ${a.availability === "available" ? "Availability reported; confirm directly before going." : "Availability has not been confirmed."}`}
        </Body>
        <Body>
          {a.lastCheckedAt
            ? `Last checked ${new Date(a.lastCheckedAt).toLocaleString()}`
            : "No verification timestamp available."}
        </Body>
        {a.source.url ? (
          <Button secondary onPress={() => void open(a.source.url!)}>
            View original source ↗
          </Button>
        ) : (
          <Body>No organizer link supplied.</Body>
        )}
      </Card>
      {message && (
        <Text accessibilityLiveRegion="polite" style={s.body}>
          {message}
        </Text>
      )}
      {unavailable && (
        <Body>
          This event is expired or unavailable. You can keep it as a reference,
          but cannot make a new plan.
        </Body>
      )}
      {finishing ? (
        <Card tint={colors.green}>
          <Text style={s.subtitle}>How did it feel?</Text>
          <Body>Entirely optional. Just for you.</Body>
          <View style={s.row}>
            {["😕", "🙂", "💛", "🤩"].map((r) => (
              <Chip
                key={r}
                label={r}
                selected={r === reaction}
                onPress={() => setReaction(r)}
              />
            ))}
          </View>
          <Field
            accessibilityLabel="Private reflection"
            placeholder="A little moment to remember…"
            value={reflection}
            onChangeText={setReflection}
            multiline
            maxLength={1000}
          />
          <Button
            disabled={busy}
            onPress={() =>
              void action(
                (s) => complete(s, a, reaction, reflection),
                "Adventure completed. A penguin is cheering you on.",
              ).then((saved) => {
                if (saved) setFinishing(false);
              })
            }
          >
            Complete adventure
          </Button>
          <Button secondary onPress={() => setFinishing(false)}>
            Not yet
          </Button>
        </Card>
      ) : q?.status === "planned" ? (
        <>
          <Button disabled={busy} onPress={() => setFinishing(true)}>
            I did it ✓
          </Button>
          <Button
            secondary
            disabled={busy}
            onPress={() =>
              void action(
                (s) => ({
                  ...s,
                  adventures: s.adventures.filter((q) => q.activityId !== id),
                }),
                "Plan canceled. No pressure.",
              )
            }
          >
            Cancel plan
          </Button>
          <Button secondary onPress={() => router.push("/quests")}>
            Explore other ideas
          </Button>
        </>
      ) : q?.status !== "completed" ? (
        <>
          <Button
            disabled={busy || unavailable}
            onPress={() =>
              void action(
                (s) => planOrSave(s, a, "planned"),
                "Planned. Enjoy your adventure!",
              )
            }
          >
            {a.type === "event" ? "I'm going" : "I'll try this"} →
          </Button>
          <Button
            secondary
            disabled={busy}
            onPress={() =>
              void action(
                (s) =>
                  q?.status === "saved"
                    ? {
                        ...s,
                        adventures: s.adventures.filter(
                          (q) => q.activityId !== id,
                        ),
                      }
                    : planOrSave(s, a, "saved"),
                q?.status === "saved"
                  ? "Removed from saved."
                  : "Saved for another day.",
              )
            }
          >
            {q?.status === "saved" ? "Remove from saved" : "Save for later ♡"}
          </Button>
        </>
      ) : (
        <Button onPress={() => router.replace("/adventures")}>
          Back to my adventures
        </Button>
      )}
    </Page>
  );
}

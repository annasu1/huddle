import { useState } from "react";
import { View, Text, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import * as Location from "expo-location";
import { useHuddle } from "../src/state/AppState";
import {
  Page,
  Title,
  Body,
  Button,
  Field,
  Penguin,
  Card,
  Label,
  Chip,
  s,
  colors,
} from "../src/components/ui";
import { Filters } from "../src/components/Filters";
import { Mood } from "../src/domain/models";
export default function Home() {
  const { state, ready, update } = useHuddle();
  const [location, setLocation] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [filters, setFilters] = useState(false),
    [discover, setDiscover] = useState(false);
  const p = state.preferences;
  const planned = state.adventures.find((a) => a.status === "planned");
  async function locate() {
    setBusy(true);
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== "granted") {
        setMessage("No problem. Enter your city or area below.");
        return;
      }
      const coords = (
        await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        })
      ).coords;
      await update((s) => ({
        ...s,
        preferences: {
          ...s.preferences,
          latitude: coords.latitude,
          longitude: coords.longitude,
        },
      }));
      setMessage(
        "Location added for distance estimates. Enter a city label below.",
      );
    } catch {
      setMessage("Location is unavailable. Manual entry works just as well.");
    } finally {
      setBusy(false);
    }
  }
  if (!ready)
    return (
      <Page>
        <ActivityIndicator />
        <Body>Opening your huddle…</Body>
      </Page>
    );
  if (!p.onboarded)
    return (
      <Page>
        <View
          style={{
            alignItems: "center",
            backgroundColor: colors.blue,
            borderRadius: 40,
            padding: 26,
            marginTop: 10,
          }}
        >
          <Text style={s.tag}>A LITTLE CURIOSITY GOES A LONG WAY</Text>
          <Penguin size={220} />
          <Text style={{ fontSize: 18, color: colors.ink, fontWeight: "600" }}>
            Meet your outside-the-routine buddy.
          </Text>
        </View>
        <Title>Less scrolling.{"\n"}More living.</Title>
        <Body>
          Three little adventures. One lovely reason to put your phone away.
          Find something that fits your day, at your own pace.
        </Body>
        <View>
          <Label>Where shall we start?</Label>
          <Field
            accessibilityLabel="City or area"
            placeholder="Your city or neighborhood"
            value={location}
            onChangeText={setLocation}
            maxLength={100}
          />
        </View>
        <Button
          disabled={!location.trim() || busy}
          onPress={() => {
            void update((s) => ({
              ...s,
              preferences: {
                ...s.preferences,
                location: location.trim(),
                onboarded: true,
              },
            })).catch(() => {});
          }}
        >
          Let's go →
        </Button>
        <Button secondary disabled={busy} onPress={() => void locate()}>
          {busy ? "Finding your location…" : "Use my location (optional)"}
        </Button>
        {message && <Body>{message}</Body>}
        <Text style={s.footnote}>
          No account. No tracking. Just a little nudge outside. {"\n"}Starts
          with sample ideas, wherever you are.
        </Text>
      </Page>
    );
  return (
    <Page tab="Discover">
      <Text style={s.tag}>⌁ {p.location}</Text>
      {planned && !discover ? (
        <>
          <Title>Your next adventure{"\n"}is waiting.</Title>
          <Card tint={colors.blue}>
            <Penguin size={110} />
            <Text style={s.subtitle}>{planned.activity.title}</Text>
            <Body>You’ve picked something lovely. The rest can wait.</Body>
            <Button
              secondary
              onPress={() =>
                router.push({
                  pathname: "/activity/[id]",
                  params: { id: planned.activityId },
                })
              }
            >
              Open my adventure →
            </Button>
          </Card>
          <Button secondary onPress={() => setDiscover(true)}>
            Change my mind / explore ideas
          </Button>
          <Body>Your plan stays in My Adventures until you cancel it.</Body>
        </>
      ) : (
        <>
          <View>
            <View style={{ flex: 1 }}>
              <Text style={s.tag}>HELLO, EXPLORER</Text>
              <Title>What are you{"\n"}in the mood for?</Title>
            </View>
          </View>
          <Body>No big plans needed. Start with a little curiosity.</Body>
          <View style={s.row}>
            {(
              ["Surprise me", "Chill", "Social", "Active", "Creative"] as Mood[]
            ).map((m, i) => (
              <Chip
                key={m}
                label={`${["✧", "☁", "☺", "↗", "✎"][i]} ${m}`}
                selected={p.mood === m}
                onPress={() => {
                  void update((s) => ({
                    ...s,
                    preferences: { ...s.preferences, mood: m },
                  })).catch(() => {});
                }}
              />
            ))}
          </View>
          <Card>
            <View
              style={{ flexDirection: "row", justifyContent: "space-between" }}
            >
              <Text style={s.label}>A little room for adventure</Text>
              <Text style={s.tag}>YOUR PACE</Text>
            </View>
            <Body>
              {p.budget === 0 ? "Free" : `Up to $${p.budget}`} · {p.distanceKm}{" "}
              km · {p.timeMinutes} minutes
            </Body>
            <Button secondary onPress={() => setFilters(!filters)}>
              {filters ? "Hide filters" : "Adjust my filters"}
            </Button>
            {filters && (
              <Filters
                value={p}
                onChange={(preferences) => {
                  void update((s) => ({ ...s, preferences })).catch(() => {});
                }}
              />
            )}
          </Card>
          <Button onPress={() => router.push("/quests")}>
            Find my next quest →
          </Button>
          <Card tint={colors.peach}>
            <Text style={s.subtitle}>Small plans. Good stories.</Text>
            <Body>
              A new path, a pencil, a friend. An adventure doesn’t have to be a
              big thing.
            </Body>
          </Card>
          <Text style={s.footnote}>
            Just three ideas at a time. No endless feed.
          </Text>
        </>
      )}
    </Page>
  );
}

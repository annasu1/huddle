import { useMemo, useState } from "react";
import { Text, View, ActivityIndicator } from "react-native";
import { useHuddle } from "../src/state/AppState";
import { recommend } from "../src/domain/recommend";
import { dismiss } from "../src/domain/actions";
import { RejectionReason } from "../src/domain/models";
import { Page, Title, Body, Button, Card, s } from "../src/components/ui";
import { ActivityCard } from "../src/components/ActivityCard";
export default function Quests() {
  const { state, catalog, update, status } = useHuddle();
  const [exclude, setExclude] = useState<string[]>([]),
    [reject, setReject] = useState<string>(),
    [message, setMessage] = useState("");
  const results = useMemo(
    () => recommend(catalog, state, Date.now(), exclude),
    [catalog, state, exclude],
  );
  async function rejectActivity(reason?: RejectionReason) {
    if (!reject) return;
    try {
      await update((s) => dismiss(s, reject, reason));
      setReject(undefined);
      setMessage("Got it. Your next ideas will take that into account.");
    } catch {}
  }
  if (status.startsWith("Loading"))
    return (
      <Page back>
        <ActivityIndicator />
        <Body>Finding your little adventures…</Body>
      </Page>
    );
  return (
    <Page back>
      <Text style={s.tag}>A LITTLE SOMETHING DIFFERENT</Text>
      <Title>Three ways to{"\n"}make today yours.</Title>
      <Body>Pick what feels good. Leave the rest.</Body>
      {message && <Body>{message}</Body>}
      {reject ? (
        <Card>
          <Text style={s.subtitle}>What didn’t feel right?</Text>
          <Body>Optional, and only used on this device.</Body>
          {(
            [
              "Too expensive",
              "Too far away",
              "Wrong timing",
              "Not available or fully booked",
              "Not my thing",
            ] as RejectionReason[]
          ).map((r) => (
            <Button key={r} secondary onPress={() => void rejectActivity(r)}>
              {r}
            </Button>
          ))}
          <Button onPress={() => void rejectActivity()}>
            Skip reason & dismiss
          </Button>
          <Button secondary onPress={() => setReject(undefined)}>
            Keep this idea
          </Button>
        </Card>
      ) : (
        <>
          {results.length < 3 && (
            <Card>
              <Body>
                {results.length
                  ? `We found ${results.length} eligible ideas. We won’t invent more to fill the page.`
                  : "You’ve explored all the matching ideas. Adjust your filters or revisit a saved adventure."}
              </Body>
            </Card>
          )}
          {results.map((r, i) => (
            <View key={r.activity.id} style={{ gap: 10 }}>
              <Text style={s.tag}>0{i + 1} / YOUR LITTLE ADVENTURE</Text>
              <ActivityCard
                {...r}
                state={state}
                onReject={() => setReject(r.activity.id)}
              />
            </View>
          ))}
          <Button
            secondary
            disabled={!results.length}
            onPress={() => {
              setExclude([...exclude, ...results.map((r) => r.activity.id)]);
              setMessage("A fresh handful, at your pace.");
            }}
          >
            Show me three more
          </Button>
          {exclude.length > 0 && (
            <Button secondary onPress={() => setExclude([])}>
              Revisit earlier ideas
            </Button>
          )}
        </>
      )}
    </Page>
  );
}

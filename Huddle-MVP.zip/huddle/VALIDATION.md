# Validation record

Executed in the supplied Linux/Node 24 workspace, with no Supabase or Apify credentials.

- `npm run typecheck`: passed.
- `npm run lint`: passed.
- `npm test`: 18 tests passed; no failed or skipped tests.
- `npx expo install --check`: compatible SDK dependencies.
- Expo web export: passed.
- Expo iOS and Android JavaScript/Hermes bundle exports: passed. These are not native signed builds.
- CSV and JSON sample import CLIs: passed, normalized output produced.
- Playwright mobile viewport (390 × 844): passed onboarding, exact-three cards, rejection feedback, save, plan, focused Home after reload, cancel/replan, complete, emoji/private reflection, history, JSON export (reflection checked), deletion confirmation cancellation, confirmed deletion. Browser interactions ran with networking disabled after initial page load. No browser page errors.
- Welcome and Home screenshots were inspected; Home title was adjusted to fit the mobile width.

The standard Playwright browser download failed in this environment; an npm-packaged Chromium binary was used for the executed smoke test. No screenshot files are included in the deliverable.

## Reproduce the browser smoke test

```sh
npm ci
npx playwright install chromium
npm run export:web
# In a separate terminal, from project root:
python3 -m http.server 8081 --directory dist
# Back in the first terminal:
npm run test:smoke
```

The smoke script starts at the root and uses client navigation; a production web host needs SPA fallback for deep links. Optional `CHROMIUM_PATH=/path/to/chromium` selects an existing browser. The script writes temporary screenshots/export JSON under `/tmp`; adapt paths on Windows. It uses fresh browser storage and never touches your ordinary browser profile.

## Still requires device/service QA

- Native SQLite persistence and permission/share-sheet behavior on physical iOS/Android devices.
- A signed release installation, followed by cold launch in airplane mode.
- VoiceOver/TalkBack, large font settings, and small-device/landscape/tablet layout testing.
- Supabase migration application and real anon-versus-service-role policy checks.
- Live Apify actor input/output compatibility, permissions, billing and Instagram availability.

Supabase and Apify integration boundaries were tested using mocked fetch responses only. No live integration or device run is claimed.

import test from "node:test";
import assert from "node:assert/strict";
import { demoActivities } from "../src/data/demo";
import { Activity, emptyState } from "../src/domain/models";
import { recommend, distanceKm } from "../src/domain/recommend";
import { normalize, normalizeMany } from "../src/domain/normalize";
import { complete, dismiss, planOrSave } from "../src/domain/actions";
import { loadCatalog, SupabaseRepository } from "../src/services/catalog";
import { InstagramApifyAdapter } from "../server/instagram";
const base = demoActivities[0];
const a = (id: string, patch: Partial<Activity> = {}): Activity => ({
  ...base,
  id,
  title: id,
  ...patch,
});
test("exactly three distinct results; honest limited and empty states", () => {
  assert.equal(recommend(demoActivities, emptyState()).length, 3);
  assert.equal(
    new Set(recommend(demoActivities, emptyState()).map((x) => x.activity.id))
      .size,
    3,
  );
  assert.equal(recommend([base], emptyState()).length, 1);
  assert.deepEqual(recommend([], emptyState()), []);
});
test("known budget and time are hard constraints; unknown metadata stays eligible", () => {
  const s = emptyState();
  s.preferences.budget = 0;
  s.preferences.timeMinutes = 30;
  const result = recommend(
    [
      a("expensive", { price: 1 }),
      a("long", { durationMinutes: 60 }),
      a("unknown", { price: undefined, durationMinutes: undefined }),
    ],
    s,
  );
  assert.deepEqual(
    result.map((x) => x.activity.id),
    ["unknown"],
  );
});
test("coordinates enforce distance; missing coordinates do not fabricate it", () => {
  const s = emptyState();
  s.preferences.latitude = 0;
  s.preferences.longitude = 0;
  s.preferences.distanceKm = 2;
  const near = a("near", { venue: { latitude: 0, longitude: 0.001 } }),
    far = a("far", { venue: { latitude: 10, longitude: 10 } });
  assert.ok(distanceKm(near, s)! < 2);
  assert.equal(distanceKm(base, s), undefined);
  assert.deepEqual(
    recommend([near, far], s).map((x) => x.activity.id),
    ["near"],
  );
});
test("expired, malformed, full, unavailable events are excluded", () => {
  const rows = [
    a("expired", { type: "event", startTime: "2020-01-01" }),
    a("bad", { type: "event", startTime: "nonsense" }),
    a("full", { availability: "full" }),
    a("unavailable", { availability: "unavailable" }),
  ];
  assert.equal(recommend(rows, emptyState()).length, 0);
});
test("future unknown availability can appear, missing event date cannot", () => {
  assert.equal(
    recommend(
      [
        a("future", { type: "event", startTime: "2099-01-01T00:00:00Z" }),
        a("nodate", { type: "event" }),
      ],
      emptyState(),
    ).length,
    1,
  );
});
test("dismissal, planning, and completion exclude activities; cancellation restores", () => {
  let s = emptyState();
  s = dismiss(s, base.id, "Too expensive");
  assert.equal(recommend([base], s).length, 0);
  s = planOrSave(emptyState(), base, "planned");
  assert.equal(recommend([base], s).length, 0);
  s = { ...s, adventures: [] };
  assert.equal(recommend([base], s).length, 1);
  s = complete(s, base, "💛", "A lovely afternoon");
  assert.equal(recommend([base], s).length, 0);
  assert.equal(s.completions[0].reflection, "A lovely afternoon");
});
test("dismissals expire after 30 days", () => {
  const s = dismiss(emptyState(), base.id);
  s.feedback[0].at = "2020-01-01";
  assert.equal(recommend([base], s).length, 1);
});
test("ranking responds to mood and positive/negative category feedback", () => {
  const s = emptyState();
  s.preferences.mood = "Creative";
  const art = a("art", { category: "Creative", moods: ["Creative"] }),
    walk = a("walk");
  assert.equal(recommend([walk, art], s)[0].activity.id, "art");
  const s2 = emptyState();
  s2.feedback = [
    {
      activityId: "old",
      kind: "reaction",
      reaction: "💛",
      at: new Date().toISOString(),
    },
  ];
  const old = a("old", { category: "Creative" });
  s2.completions = [
    { activityId: "old", completedAt: new Date().toISOString() },
  ];
  assert.equal(recommend([walk, art, old], s2)[0].activity.id, "art");
});
test("diversity favors another category; challenge ceiling respected", () => {
  const rows = [
    a("a"),
    a("b"),
    a("c"),
    a("d", { category: "Creative" }),
    a("stretch", { challenge: "Stretch" }),
  ];
  const result = recommend(rows, emptyState());
  assert.ok(result.some((x) => x.activity.category === "Creative"));
  assert.ok(!result.some((x) => x.activity.id === "stretch"));
});
test("normalization sanitizes optional values and rejects malformed required fields", () => {
  const result = normalize({
    ...base,
    price: "oops",
    venue: { latitude: 99, longitude: "bad" },
    durationMinutes: -3,
    source: { platform: "curated", url: "javascript:alert(1)" },
    lastCheckedAt: "bad",
  });
  assert.equal(result.price, undefined);
  assert.equal(result.venue?.latitude, undefined);
  assert.equal(result.durationMinutes, undefined);
  assert.equal(result.source.url, undefined);
  assert.equal(result.lastCheckedAt, undefined);
  assert.throws(() => normalize({ title: "missing fields" }));
  assert.throws(() => normalize({ ...base, type: "event", startTime: "bad" }));
});
test("deduplication handles source IDs, canonical URLs and matching titles", () => {
  const result = normalizeMany([
    a("a", {
      source: {
        platform: "curated",
        url: "https://example.com/e?utm_source=x",
      },
    }),
    a("b", { source: { platform: "curated", url: "https://example.com/e" } }),
    a("c", { source: { platform: "curated", sourceId: "123" } }),
    a("d", { source: { platform: "curated", sourceId: "123" } }),
    null,
  ]);
  assert.equal(result.activities.length, 2);
  assert.equal(result.duplicates, 2);
  assert.equal(result.errors[0].row, 5);
});
test("Supabase reads with public key, normalizes payload and falls back offline", async () => {
  let called = "";
  const fetcher: typeof fetch = async (input, init) => {
    called = String(input);
    assert.equal((init?.headers as Record<string, string>).apikey, "public");
    return new Response(JSON.stringify([{ payload: base }]), { status: 200 });
  };
  const repo = new SupabaseRepository("https://example.com", "public", fetcher);
  assert.equal((await repo.list())[0].id, base.id);
  assert.match(called, /published=eq.true/);
  const bad = new SupabaseRepository(
    "https://example.com",
    "public",
    async () => {
      throw Error("offline");
    },
  );
  assert.equal((await loadCatalog(bad, [base])).activities[0].id, base.id);
  assert.ok((await loadCatalog(bad, [])).status.includes("demo"));
});
test("Supabase rejects malformed responses and HTTP errors", async () => {
  for (const res of [
    new Response("{}"),
    new Response("[]", { status: 403 }),
    new Response('[{"payload":{}}]'),
  ]) {
    await assert.rejects(
      new SupabaseRepository(
        "https://example.com",
        "public",
        async () => res,
      ).list(),
    );
  }
});
test("Apify candidate discovery never invents event facts and handles rate limits", async () => {
  const source = new InstagramApifyAdapter(
    "server-secret",
    ["https://instagram.com/example"],
    async () =>
      new Response(
        JSON.stringify([
          {
            id: "1",
            url: "https://instagram.com/p/x",
            caption: "Try something",
            timestamp: "2026-01-01",
          },
          {},
        ]),
      ),
  );
  const result = await source.discover();
  assert.equal(result.candidates.length, 1);
  assert.equal(
    (result.candidates[0] as Record<string, unknown>).startTime,
    undefined,
  );
  await assert.rejects(
    new InstagramApifyAdapter(
      "x",
      ["url"],
      async () => new Response("", { status: 429 }),
    ).discover(),
    /rate limited/,
  );
});

test("engine itself guards duplicate IDs", () => {
  const results = recommend(
    [base, base, a("second"), a("third")],
    emptyState(),
  );
  assert.equal(results.length, 3);
  assert.equal(new Set(results.map((r) => r.activity.id)).size, 3);
});
test("missing currency remains eligible, unsupported known currency does not", () => {
  assert.equal(
    recommend(
      [
        a("unknown-currency", { currency: undefined }),
        a("eur", { price: 20, currency: "EUR" }),
      ],
      emptyState(),
    ).length,
    1,
  );
});
test("negative category feedback lowers future related ideas", () => {
  const s = emptyState();
  s.feedback = [
    {
      activityId: "old-art",
      kind: "dismissed",
      reason: "Not my thing",
      at: new Date().toISOString(),
    },
  ];
  const result = recommend(
    [
      a("old-art", { category: "Creative" }),
      a("a-art", { category: "Creative" }),
      a("z-walk"),
    ],
    s,
  );
  assert.equal(result[0].activity.id, "z-walk");
});

test("local adapter retains distinct upcoming and unknown-metadata samples", async () => {
  const { DemoRepository } = await import("../src/services/catalog");
  const rows = await new DemoRepository().list();
  assert.ok(rows.find((a) => a.id === "demo-upcoming"));
  assert.ok(rows.find((a) => a.id === "demo-open"));
});
